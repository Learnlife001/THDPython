print("The following exercises are done by Ant Maung Maung")

print("Exercise 1")

def greeting(first_name, last_name = ""):
    print("Hello, " + first_name + " " + last_name+". Welcome Back.")

greeting("Ant", "Maung Maung")
greeting("Ant")

print("____________________")

print("exercise 2")
def find_max(*number):
    maximum = number[0]
    for number in number:
        if number > maximum:
            maximum = number
    return maximum

max = find_max(1,2,3,4,5)
print(max)

print("____________________")

print("exercise 3")
def find_average(*number):
    if number:
        average = sum(number) / len(number)
        return average
    else:
        return 0

print(find_average(1,2,3,4,5))
print(find_average())

print("____________________")

print("exercise 4")
def filter_even(*number):
    even = []
    for n in number:
        if n % 2 == 0:
            even.append(n)
    return even

print(filter_even(0,1,2,3,4,5))

print("____________________")

print("exercise 5")
def factorial(n):
    if n<1:
        print("Invalid input")
        return None
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

print(factorial(5))
print(factorial(-5))

print("____________________")

print("exercise 6")
def write_lines(filename,lines):
    with open(filename,"w") as file:
        for line in lines:
            file.write(line + "\n")

the_file_name = "AMM_text_file.txt"
lines_to_write = [
    "First line.",
    "Second line.",
    "second line.",
    "Third and final line.",
    "AndOneForTesting.",
    "Repeated line."
]

write_lines(the_file_name, lines_to_write)

print("Please check the output file")

print("____________________")

print("exercise 7")
def count_words(filename):
    the_words = []
    space_newline = " \n"
    current_word = ""
    with open(filename,"r") as file:
        content = file.read()
    for chr in content:
        if chr in space_newline:
            if current_word:
                the_words.append(current_word)
                current_word = ""
        else:
            current_word += chr

    return len(the_words)

print(count_words(the_file_name))

print("____________________")

print("exercise 8")
def longest_length(filename):
    max_length = 0
    with open(filename, "r") as file:
        for line in file:
            current_length = len(line.strip())

            if current_length > max_length:
                max_length = current_length
                longest_sentence= line.strip()

    return longest_sentence

l = longest_length(the_file_name)
print("The longest sentence is: ",l)

print("____________________")

print("exercise 9")
def reverse_file(input_file, output_file):
    with open(input_file, "r") as file:
        content = file.readlines()

    reversed_content = []
    for line in content:
        reversed_content.insert(0, line)

    with open(output_file, "w") as file:
        for line in reversed_content:
            file.write(line)

reverse_file("AMM_text_file.txt", "AMM_reversed_text_file.txt")
print("Please check the output file for result.")

print("____________________")

print("exercise 10")
def word_frequency(filename):
    the_words = []
    space_newline = " \n"
    current_word = ""
    with open(filename, "r") as file:
        content = file.read()
    for chr in content:
        if chr in space_newline:
            if current_word:
                the_words.append(current_word)
                current_word = ""
        else:
            current_word += chr

    case_sensitive_list = []
    for word in the_words:
        case_sensitive_list.append(word.lower())

    frequency = {}

    for word in case_sensitive_list:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1

    return frequency

print(word_frequency(the_file_name))


print("________________________________________________________________________________________")
#The following exercises are done by Manthan Amol Patki
print('The following exercises are done by Manthan Amol Patki')
# Exercise 1:
print('\nExercise 1:')
def greet_user(first_name, last_name = ""):
    print(f'Hello, {first_name} {last_name}! Welcome Back!')
greet_user('Bob') #Example, should print just 'Hello, Bob! Welcome Back!'
greet_user('Bob', last_name = 'Ross') #Should print “Hello, Bob Ross! Welcome back!”

# Exercise 2:
print('\nExercise 2: ')
def find_max(a,b,c):
    numbers = [a,b,c]
    maximum = numbers[0]
    for number in numbers:
        if number > maximum:
            maximum = number
    return maximum

print(find_max(-1999923,-2323123232,56453))

# Exercise 3:
print('\nExercise 3: ')
def average(numbers):
    if len(numbers)  == 0: # if an empty string is passed
        return 0
    else:
        sum_of_numbers = 0
        for number in numbers:
            sum_of_numbers += number
        average_of_numbers = sum_of_numbers/len(numbers)
        return average_of_numbers

example_list = [5,6,7,8,9,10] #example list to find the average of
print(f'Average of the list {example_list} is {average(example_list)}')

#Exercise 4:
print('\nExercise 4: ')
def filter_even(number_list):
    even_list = []
    for number in number_list:
        if number % 2 == 0:
            even_list.append(number)
    return even_list
example_list = [5,34,2,7,4,23,78]
print(f'Even in the of the list {example_list} is {filter_even(example_list)}')

# Exercise 5:
print('\nExercise 5: ')
def factorial(n):
    if n == 0:
        return 1
    elif n < 0:
        print('invalid input')
        return 'invalid input'
    else:
        return n * factorial(n-1)
print(f'The factorial of -5 is {factorial(-5)}') #testing on negative numbers
print(f'The factorial of 6 is {factorial(6)}') #testing on 6, should return 6

#Exercise 6
print('\nExercise 6: ')
def write_lines(filename, lines):
    with open(filename, 'w') as file:
        for line in lines:
            file.write(line + '\n')
list_of_strings = ['hello', 'world', 'testing', 'writing', 'in', 'files']
print(f'{list_of_strings} will be written in the file "files_for_exercise/Exercise_6.txt" after the function is called')
write_lines('files_for_exercise/Exercise_6.txt', list_of_strings)

#Exercise 7:
print('\nExercise 7: ')
def count_words(filename):
    with open(filename) as file:
        content = file.read()
    # replacing all new lines with space to put all the content of the file into one line
    content_on_one_line = content.replace('\n', ' ')
    words = content_on_one_line.split(' ')
    return len(words)
print(f'Content contained in the file "files_for_exercise/Exercise_7.txt" : \nword1 word2 word3 word4 word5 \nword6 word7 word8 word9 word10 word11 \nhas {count_words("files_for_exercise/Exercise_7.txt")} words')

#Exercise 8:
print('\nExercise 8: ')
def longest_length(filename):
    with open(filename, 'r') as file:
        maximum = -1 # since length of a line will be atleast 0
        biggest_line = ""
        for line in file:
            if len(line) > maximum:
                maximum = len(line)
                biggest_line = line
    return maximum, biggest_line
maximum, biggest_line = longest_length("files_for_exercise/Exercise_8.txt")
print('The contents of the file "files_for_exercise/Exercise_8.txt" are: \nThis is line 1 \nThis is the second line \nThis line comes third in the sequence\n')
print(f'The longest line is "{biggest_line}" with a length of {maximum}')

#Exercise 9:
print('\nExercise 9: ')
def reverse_file(input_file, output_file):
    lines = []
    with open(input_file, 'r') as input_file:
        for line in input_file:
            lines.append(line.strip( ))
    with open(output_file, 'w') as output_file:
        for i in range(len(lines)-1, -1, -1): #going from last index to 0
            output_file.write(lines[i]+'\n')

print('The file "files_for_exercise/Exercise_9_input.txt" contains the following lines:\nline 1 \nline 2 \nline 3 \nline 4 \nline 5')
reverse_file ("files_for_exercise/Exercise_9_input.txt", "files_for_exercise/Exercise_9_output.txt")
print('After the function reverse_file(input_path, output_path) is called, the file "files_for_exercise/Exercise_9_output.txt" will contain the following lines: \nline 5 \nline 4 \nline 3 \nline 2 \nline 1')

#Exercise 10:
print('\nExercise 10: ')
def word_frequency(filename):
    with open(filename, 'r') as file:
        file_content = file.read()
    # putting all the content on the same line in one string and removing punctuation
    file_content = file_content.replace('\n', ' ').replace('.', '').replace(',', '')
    file_content = file_content.lower() # to make everything lower case
    words = file_content.split(' ')
    word_frequency = {}
    for word in words:
        if word in word_frequency:
            word_frequency[word] += 1
        else:
            word_frequency[word] = 1
    print('Here is a list of all the words along with their frequency')
    for word in word_frequency:
        print(f'Frequency of {word}: {word_frequency[word]}')
    return word_frequency
print(f'The contents of the file "files_for_exercise/Exercise_10.txt" are: \nThis file is for demonstration. \nHence, for DEMONSTRATION, the words in this FILE are repeated.\n')
word_frequency('files_for_exercise/Exercise_10.txt')

print("________________________________________________________________________________________")
#The following exercises are done by Okuma Chigozie
print('The following exercises are done by  Okuma Chigozie')

# exercise 1 greet_user
print('\nExercise 1: ')
def greet(first_name, last_name=""):
    if last_name == "":
        print(f"Hello, {first_name}! Welcome back!")
    else:
        print(f"Hello, {first_name} {last_name}! Welcome back!")


greet("Bob", "Ross")
greet("Bob")

# exercise 2 find_max
print('\nExercise 2: ')

def find_max(a, b, c):
    if a >= b and a >= c:
        return a
    elif b >= a and b >= c:
        return b
    else:
        return c


result = find_max(2, 4, 6)
print("The largest number is:", result)

# exercise 3 average

print('\nExercise 3: ')
def average(numbers):
    if len(numbers) == 0:
        return 0
    total = 0
    for n in numbers:
        total = total + n
        average = total / len(numbers)
    return average


result = average([2, 3, 5, 6, 8])
print("Average:", result)


# exercise 4 filter_ever
print('\nExercise 4: ')
def filter_even(numbers):
    even_numbers = []
    for n in numbers:
        if n % 2 == 0:
            even_numbers.append(n)
    return even_numbers


result = filter_even([1, 2, 3, 6, 5])
print("Even numbers:", result)


# exercise 5 factorial
print('\nExercise 5: ')
def factorial(n):
    if n < 0:
        return "Invalid Input"
    elif n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)


result = factorial(-1)
print("Factorial is:", result)


# exercise 6 write_lines
print('\nExercise 6: ')
def write_lines(filename, lines):
    with open(filename, "w") as f:
        for line in lines:
            f.write(line + "\n")


lines = ["Hello", "up is good", "that is all"]
write_lines("my.txt", lines)
print("Lines in file")


# exercise 7 count_words
print('\nExercise 7: ')
def count_words(filename):
    with open(filename, "r") as f:
        content = f.read()
        words = content.split()
        print("Number of words:", len(words))


count_words("my.txt")


# exercise 8 longest_length
print('\nExercise 8: ')
def longest_length(filename):
    with open(filename, "r") as f:
        longest_line = ""
        for line in f:
            if len(line) > len(longest_line):
                longest_line = line
        print("Longest line:")
        print(longest_line)


longest_length("my.txt")


# exercise 9 reverse_file
print('\nExercise 9: ')
def reverse_file(input_file, output_file):
    with open(input_file, "r") as f:
        lines = f.readlines()
    print("Lines reversed:", len(lines))
    reversed_lines = []
    index = len(lines) - 1
    while index >= 0:
        reversed_lines.append(lines[index])
        index = index - 1
    with open(output_file, "w") as f:
        for line in reversed_lines:
            f.write(line)


reverse_file("my.txt", "reversed_my.txt")


# exercise 10 word_frequency
print('\nExercise 10: ')
def word_frequency(filename):
    with open(filename, "r") as f:
        content = f.read()
        content = content.lower()
        words = content.split()
        frequency = {}

        for word in words:
            if word in frequency:
                frequency[word] = frequency[word] + 1
            else:
                frequency[word] = 1

        print("Word frequency:")
        for word in frequency:
            print(word, ":", frequency[word])


word_frequency("my.txt")
